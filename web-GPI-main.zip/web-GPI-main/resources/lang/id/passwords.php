<?php

return [
    'reset' => 'Password Anda telah direset!',
    'sent' => 'Kami telah mengirim email dengan link reset password Anda!',
    'throttled' => 'Silakan tunggu sebelum mencoba lagi.',
    'token' => 'Token reset password ini tidak valid.',
    'user' => 'Kami tidak dapat menemukan pengguna dengan alamat email tersebut.',
];
